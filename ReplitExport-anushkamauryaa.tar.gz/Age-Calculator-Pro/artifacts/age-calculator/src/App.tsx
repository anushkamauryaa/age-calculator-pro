import { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const queryClient = new QueryClient();

function calculateAge(birthDate: Date, today: Date) {
  let years = today.getFullYear() - birthDate.getFullYear();
  let months = today.getMonth() - birthDate.getMonth();
  let days = today.getDate() - birthDate.getDate();

  if (days < 0) {
    months -= 1;
    const prevMonth = new Date(today.getFullYear(), today.getMonth(), 0);
    days += prevMonth.getDate();
  }

  if (months < 0) {
    years -= 1;
    months += 12;
  }

  return { years, months, days };
}

function daysUntilNextBirthday(birthDate: Date, today: Date): number {
  const nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
  if (nextBirthday < today || nextBirthday.toDateString() === today.toDateString()) {
    nextBirthday.setFullYear(today.getFullYear() + 1);
  }
  const diff = nextBirthday.getTime() - today.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

interface AgeResult {
  years: number;
  months: number;
  days: number;
  nextBirthdayDays: number;
  isBirthdayToday: boolean;
}

function AgeCalculator() {
  const [birthDateStr, setBirthDateStr] = useState("");
  const [result, setResult] = useState<AgeResult | null>(null);
  const [error, setError] = useState("");
  const [calculated, setCalculated] = useState(false);

  const today = new Date();
  const maxDate = today.toISOString().split("T")[0];

  const handleCalculate = () => {
    setError("");
    if (!birthDateStr) {
      setError("Please select your birth date.");
      return;
    }
    const birth = new Date(birthDateStr + "T00:00:00");
    if (birth > today) {
      setError("Birth date cannot be in the future.");
      return;
    }
    const age = calculateAge(birth, today);
    const isBirthdayToday =
      birth.getMonth() === today.getMonth() && birth.getDate() === today.getDate();
    const nextBirthdayDays = isBirthdayToday ? 365 : daysUntilNextBirthday(birth, today);
    setResult({ ...age, nextBirthdayDays, isBirthdayToday });
    setCalculated(true);
  };

  const handleReset = () => {
    setBirthDateStr("");
    setResult(null);
    setError("");
    setCalculated(false);
  };

  return (
    <div className="app-wrapper">
      {/* Header */}
      <header className="app-header">
        <div className="header-inner">
          <div className="header-icon">🎂</div>
          <h1 className="header-title">Age Calculator Pro</h1>
          <p className="header-subtitle">Discover exactly how old you are — to the day</p>
        </div>
      </header>

      {/* Main content */}
      <main className="app-main">
        <div className="card">
          <div className="card-body">
            <label className="field-label" htmlFor="birthdate">
              Select Your Birth Date
            </label>
            <div className="input-row">
              <div className="input-wrapper">
                <span className="input-icon">📅</span>
                <input
                  id="birthdate"
                  type="date"
                  className="date-input"
                  value={birthDateStr}
                  max={maxDate}
                  onChange={(e) => {
                    setBirthDateStr(e.target.value);
                    setError("");
                  }}
                />
              </div>
              <button className="btn-calculate" onClick={handleCalculate}>
                Calculate Age
              </button>
            </div>
            {error && <p className="error-msg">{error}</p>}
          </div>
        </div>

        {calculated && result && (
          <div className="results-section">
            {result.isBirthdayToday && (
              <div className="birthday-banner">
                🎉 Happy Birthday! Wishing you an amazing day! 🎂
              </div>
            )}

            <div className="age-grid">
              <div className="age-card age-card--years">
                <span className="age-number">{result.years}</span>
                <span className="age-unit">Years</span>
              </div>
              <div className="age-card age-card--months">
                <span className="age-number">{result.months}</span>
                <span className="age-unit">Months</span>
              </div>
              <div className="age-card age-card--days">
                <span className="age-number">{result.days}</span>
                <span className="age-unit">Days</span>
              </div>
            </div>

            <div className="birthday-countdown">
              <div className="countdown-icon">🎁</div>
              <div className="countdown-text">
                {result.isBirthdayToday ? (
                  <span>Today is your Birthday! 🥳</span>
                ) : (
                  <>
                    <span className="countdown-days">{result.nextBirthdayDays}</span>
                    <span> days until your next birthday</span>
                  </>
                )}
              </div>
            </div>

            <div className="extra-info">
              <div className="info-row">
                <span className="info-label">Total months lived</span>
                <span className="info-value">{result.years * 12 + result.months}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Total weeks lived</span>
                <span className="info-value">
                  {Math.floor((result.years * 365.25 + result.months * 30.44 + result.days) / 7)}
                </span>
              </div>
              <div className="info-row">
                <span className="info-label">Total days lived</span>
                <span className="info-value">
                  {Math.floor(result.years * 365.25 + result.months * 30.44 + result.days)}
                </span>
              </div>
            </div>

            <button className="btn-reset" onClick={handleReset}>
              Reset Calculator
            </button>
          </div>
        )}

        {/* Digital Heroes Button */}
        <div className="dh-section">
          <a
            href="https://digitalheroesco.com"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-dh"
          >
            <span className="btn-dh-icon">⚡</span>
            Built for Digital Heroes
          </a>
        </div>
      </main>

      {/* Footer */}
      <footer className="app-footer">
        <p className="footer-credit">
          Created by: <strong>Anushka Maurya</strong>
        </p>
        <p className="footer-email">
          Email:{" "}
          <a href="mailto:anushkamaurya1609@gmail.com" className="footer-link">
            anushkamaurya1609@gmail.com
          </a>
        </p>
      </footer>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AgeCalculator />
    </QueryClientProvider>
  );
}

export default App;
